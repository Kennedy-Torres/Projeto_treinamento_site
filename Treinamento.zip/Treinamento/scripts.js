/*
function trocaCor(){ // está função sera executada, segundo o html, toda vez que clicar uma vez no botão 
    let circulo = document.querySelector(".circulo") // ele vai consultar a classe circulo que esta no html
    circulo.style.background = "#d4d634" // e ira executar essa ação .... mudar a cor do circulo
} 
// agora eu teria que fazer a mesma coisa para todos os outros botões..... ou fazer uma função inteligente
*/
function trocaCor(cor){ // a variavel cor muda para cada butão que eh precionado, uma vez que possui dados diferentes escritos no html
    let Novocirculo = document.querySelector(".circulo") // eh criado uma nova variavel (= Novocirculo) que ira armazenar os mesmos dados que estão na classe circulo <-> (.circulo)
    Novocirculo.style.background = cor // nome da variavel_no_js ... vai alterar o style ... vai alterar o background
} // função inteligente

function trocaImg(imagem){
    let Novaimg = document.querySelector(".img_iphone")
    Novaimg.src = imagem
}
